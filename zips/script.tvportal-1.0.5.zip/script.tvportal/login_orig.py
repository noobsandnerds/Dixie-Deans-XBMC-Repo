#
#      Copyright (C) 2016 noobsandnerds.com
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import xbmc, xbmcaddon, xbmcgui, os, re, urllib, urllib2
import time, dixie, shutil, binascii, hashlib
import extract, download, sfile
from sqlite3 import dbapi2 as sqlite

def converthex(url):
    return binascii.unhexlify(url)

AddonID          =  'script.tvportal'
ADDON            =  xbmcaddon.Addon(id=AddonID)
USERDATA         =  xbmc.translatePath(converthex('7370656369616c3a2f2f686f6d652f7573657264617461'))
ADDON_DATA       =  xbmc.translatePath(os.path.join(USERDATA,converthex('6164646f6e5f64617461')))
ADDONS           =  xbmc.translatePath(converthex('7370656369616c3a2f2f686f6d652f6164646f6e73'))
chanxml          =  os.path.join(ADDON_DATA,AddonID,converthex('6368616e2e786d6c'))
xmlmaster        =  os.path.join(ADDONS,AddonID,converthex('7265736f7572636573'),converthex('6368616e2e786d6c'))
installfile      =  os.path.join(ADDONS,AddonID,converthex('6c6f67696e2e7079'))
firstrun         =  os.path.join(ADDON_DATA,AddonID,converthex('666972737472756e2e747874'))
updateicon       =  os.path.join(ADDONS,AddonID,converthex('7265736f7572636573'),converthex('7570646174652e706e67'))
bakfile          =  os.path.join(ADDONS,AddonID,converthex('7265736f7572636573'),converthex('6261636b7570'))
cookie           =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,converthex('636f6f6b696573'),converthex('74656d70')))
login            =  ADDON.getSetting(converthex('6c6f67696e'))
forum            =  ADDON.getSetting(converthex('666f72756d'))
username         =  ADDON.getSetting(converthex('757365726e616d65')).replace(' ','%20')
password         =  ADDON.getSetting(converthex('70617373776f7264'))
remoteshare      =  ADDON.getSetting(converthex('72656d6f74657368617265'))
remotelocation   =  ADDON.getSetting(converthex('72656d6f74656c6f636174696f6e'))
showSFchannels   =  ADDON.getSetting(converthex('73686f7753466368616e6e656c73'))
SF_CHANNELS      =  ADDON.getSetting(converthex('53465f4348414e4e454c53'))
channelFolder    =  dixie.GetChannelFolder()
channelPath      =  os.path.join(channelFolder,converthex('6368616e6e656c73'))
dialog           =  xbmcgui.Dialog()
dbpath           =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,converthex('70726f6772616d2e6462')))
logourl          =  converthex('687474703a2f2f6e6f6f6273616e646e657264732e636f6d2f43505f53747566662f646f776e6c6f61642e7068703f783d6c6f676f26693d257326753d257326703d2573') % (AddonID,username,password)
iniurl           =  converthex('687474703a2f2f6e6f6f6273616e646e657264732e636f6d2f43505f53747566662f646f776e6c6f61642e7068703f783d696e6926693d257326753d257326703d2573') % (AddonID,username,password)
epgskinurl       =  converthex('687474703a2f2f6e6f6f6273616e646e657264732e636f6d2f43505f53747566662f646f776e6c6f61642e7068703f783d736b696e26693d257326753d257326703d2573') % (AddonID,username,password)
logodst          =  xbmc.translatePath(converthex('7370656369616c3a2f2f686f6d652f6164646f6e732f7061636b616765732f74767065'))
inidst           =  xbmc.translatePath(converthex('7370656369616c3a2f2f686f6d652f6164646f6e732f7061636b616765732f74767069'))
channdst         =  xbmc.translatePath(converthex('7370656369616c3a2f2f686f6d652f6164646f6e732f7061636b616765732f74767063'))
epgskindst       =  xbmc.translatePath(converthex('7370656369616c3a2f2f686f6d652f6164646f6e732f7061636b616765732f7476706573'))
stop             =  0
if forum == converthex('556e6f6666696369616c204b6f646920537570706f7274'):
    forum = 'k'
if forum == converthex('436f6d6d756e697479204275696c647320537570706f7274'):
    forum = 'c'

xmlfile = converthex('6164646f6e2e786d6c')
addonxml = xbmc.translatePath(os.path.join(ADDONS,AddonID,xmlfile))
localaddonversion = open(addonxml, mode='r')
content = file.read(localaddonversion)
file.close(localaddonversion)
localaddonvermatch = re.compile('<ref>(.+?)</ref>').findall(content)
addonversion  = localaddonvermatch[0] if (len(localaddonvermatch) > 0) else ''
localcheck = hashlib.md5(open(installfile,'rb').read()).hexdigest()
if addonversion != localcheck:
  readfile = open(bakfile, mode='r')
  content  = file.read(readfile)
  file.close(readfile)
  writefile = open(installfile, mode='w+')
  writefile.write(content)
  writefile.close()

def Check_File_Date(url, datefile, localdate, dst):
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        conn = urllib2.urlopen(req)
        last_modified = conn.info().getdate('last-modified')
        last_modified = time.strftime('%Y%m%d%H%M%S', last_modified)
        if int(last_modified) > int(localdate):
            download.download(url,dst)
            extract.all(dst,xbmc.translatePath('special://profile/addon_data'))
            writefile = open(datefile, 'w+')
            writefile.write(last_modified)
            writefile.close()
        try:
            if os.path.exists(dst):
                os.remove(dst)
        except:
            pass
    except:
        dixie.log("Failed with update: "+str(url))

def Check_Updates(url, datefile, dst):
    if os.path.exists(datefile):
        readfile = open(datefile,'r')
        localdate = readfile.read()
        readfile.close()
    else:
        localdate = 0
    Check_File_Date(url, datefile, int(localdate), dst)

def Open_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 10.0; WOW64; Windows NT 5.1; en-GB; rv:1.9.0.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36 Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link     = response.read()
    response.close()
    return link.replace('\r','').replace('\n','').replace('\t','')


def Timestamp():
    now = time.time()
    localtime = time.localtime(now)
    return time.strftime('%Y%m%d%H%M%S', localtime)


def User_Info():
    BaseURL       = converthex('687474703a2f2f6e6f6f6273616e646e657264732e636f6d2f54492f6c6f67696e2f6c6f67696e5f6e6f6f62732e7068703f753d257326703d257326663d2573') % (username, password, forum)
    try:
        link          = Open_URL(BaseURL)
        link          = binascii.unhexlify(link)
    except:
        dialog.ok(ADDON.getLocalizedString(30833),ADDON.getLocalizedString(30834))
        return
    welcomematch  = re.compile('l="(.+?)"').findall(link)
    welcometext   = welcomematch[0] if (len(welcomematch) > 0) else ''
    ipmatch       = re.compile('i="(.+?)"').findall(link)
    ipclean       = ipmatch[0] if (len(ipmatch) > 0) else '0.0.0.0'
    emailmatch    = re.compile('e="(.+?)"').findall(link)
    email         = emailmatch[0] if (len(emailmatch) > 0) else 'Unknown'
    postsmatch    = re.compile('p="(.+?)"').findall(link)
    posts         = postsmatch[0] if (len(postsmatch) > 0) else '0'
    unreadmatch   = re.compile('u="(.+?)"').findall(link)
    unread        = unreadmatch[0] if (len(unreadmatch) > 0) else '0'
    messagematch  = re.compile('m="(.+?)"').findall(link)
    messages      = messagematch[0] if (len(messagematch) > 0) else '0'

    if converthex('72656163746976617465') in welcometext:
        try:
            os.remove(cookie)
        except:
            pass
        dialog.ok(ADDON.getLocalizedString(30831),ADDON.getLocalizedString(30832))
    elif converthex('63757272656e746c792072657374726963746564') in welcometext:
        dialog.ok(ADDON.getLocalizedString(30829),ADDON.getLocalizedString(30830))
    elif converthex('57726f6e672050617373776f726420456e7465726564') in welcometext:
        try:
            os.remove(cookie)
        except:
            pass
        dialog.ok(ADDON.getLocalizedString(30825),ADDON.getLocalizedString(30826))
        ADDON.openSettings()
    elif converthex('524547495354455220464f522046524545') in welcometext:
        try:
            os.remove(cookie)
        except:
            pass
        dialog.ok(ADDON.getLocalizedString(30827),ADDON.getLocalizedString(30828))
        ADDON.openSettings()
    elif login == 'true' and username == '' and password == '':
        dialog.ok(ADDON.getLocalizedString(30835),ADDON.getLocalizedString(30836))
        ADDON.openSettings()        
    else:
        writefile = open(cookie, mode='w+')
        writefile.write(encryptme('e','d="'+str(Timestamp())+'"|w="'+welcometext+'"|i="'+ipclean+'"|e="'+email+'"|m="'+messages+'"|u="'+unread+'"p="'+posts+'"'))
        writefile.close()
        Check_Updates(logourl, xbmc.translatePath(converthex('7370656369616c3a2f2f70726f66696c652f6164646f6e5f646174612f')+AddonID+converthex('2f6c6f676f63686b')), logodst)
        Check_Updates(iniurl, xbmc.translatePath(converthex('7370656369616c3a2f2f70726f66696c652f6164646f6e5f646174612f')+AddonID+converthex('2f696e6963686b')), inidst)
        if remoteshare == 'true':
            Check_Updates(remotelocation, xbmc.translatePath(converthex('7370656369616c3a2f2f70726f66696c652f6164646f6e5f646174612f')+AddonID+converthex('2f6368616e63686b')), channdst)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        main()

def verify():
    if login == 'true' and (username == '' or password == ''):
        dialog.ok(ADDON.getLocalizedString(30835),ADDON.getLocalizedString(30836))
        ADDON.openSettings()

    else:

        if not os.path.exists(cookie):
            User_Info()

        else:
            cookiefile = open(cookie, mode='r')
            cookietext = cookiefile.read()
            cookiefile.close()

            localfile          = open(cookie, mode='r')
            content            = localfile.read()
            content            = encryptme('d',content)
            localfile.close()
        
            userdatematch       = re.compile('d="(.+?)"').findall(content)
            loginmatch          = re.compile('w="(.+?)"').findall(content)
            ipmatch             = re.compile('i="(.+?)"').findall(content)
            updatecheck         = userdatematch[0] if (len(userdatematch) > 0) else '0'
            welcometext         = loginmatch[0] if (len(loginmatch) > 0) else ''
            ipclean             = ipmatch[0] if (len(ipmatch) > 0) else '0.0.0.0'
            myip = getIP()

            xbmc.executebuiltin("XBMC.Notification("+ADDON.getLocalizedString(30807)+","+ADDON.getLocalizedString(30808)+",10000,"+updateicon+")")
            if converthex('72656163746976617465') in welcometext:
                try:
                    os.remove(cookie)
                except:
                    pass
                dialog.ok(ADDON.getLocalizedString(30831),ADDON.getLocalizedString(30832))
            elif converthex('63757272656e746c792072657374726963746564') in welcometext:
                dialog.ok(ADDON.getLocalizedString(30829),ADDON.getLocalizedString(30830))
            elif converthex('57726f6e672050617373776f726420456e7465726564') in welcometext:
                try:
                    os.remove(cookie)
                except:
                    pass
                dialog.ok(ADDON.getLocalizedString(30825),ADDON.getLocalizedString(30826))
                ADDON.openSettings()
            elif converthex('524547495354455220464f522046524545') in welcometext:
                try:
                    os.remove(cookie)
                except:
                    pass
                dialog.ok(ADDON.getLocalizedString(30827),ADDON.getLocalizedString(30828))
                ADDON.openSettings()
            elif int(updatecheck)+1000000 > int(Timestamp()) and ipclean == myip:
                Check_Updates(logourl, xbmc.translatePath(converthex('7370656369616c3a2f2f70726f66696c652f6164646f6e5f646174612f')+AddonID+converthex('2f6c6f676f63686b')), logodst)
                Check_Updates(iniurl, xbmc.translatePath(converthex('7370656369616c3a2f2f70726f66696c652f6164646f6e5f646174612f')+AddonID+converthex('2f696e6963686b')), inidst)
                if remoteshare == 'true':
                    Check_Updates(remotelocation, xbmc.translatePath(converthex('7370656369616c3a2f2f70726f66696c652f6164646f6e5f646174612f')+AddonID+converthex('2f6368616e63686b')), channdst)
                xbmc.executebuiltin('Dialog.Close(busydialog)')
                main()
            
            else:
                User_Info()

def getIP():
    BaseURL       = converthex('687474703a2f2f7768617469736d796970616464726573732e636f6d')
    link          = Open_URL(BaseURL).replace('\n','').replace('\r','')
    ipmatch       = re.compile(converthex('7768617469736d796970616464726573732e636f6d2f')+'ip/(.+?)"').findall(link)
    ipfinal       = ipmatch[0] if (len(ipmatch) > 0) else ''
    return ipfinal
    

def encryptme(mode, message):
    finaltext = ''
    if mode == 'e':
        finaltext = ''
        offset = len(username)
    # enctrypt/decrypt the message
        translated = ''
        finalstring = ''
        for symbol in message:
                num = ord(symbol)+offset
                if len(str(num))==2:
                    num = '0'+str(num)
                finalstring = str(finalstring)+str(num)
        return finalstring+finaltext
    else:
        key    = len(username)
        messagearray = [message[i:i+3] for i in range(0, len(message), 3)]
        for item in messagearray:
            item = int(item)-key
            item = str(unichr(item))
            finaltext = finaltext+item
        return finaltext

        
def Check_Skin_Updates():
    Check_Updates(epgskinurl, xbmc.translatePath(converthex('7370656369616c3a2f2f70726f66696c652f6164646f6e5f646174612f')+AddonID+'/epgskinchk'), epgskindst)


def SF_Folder_Count():
    channels       = []
    channelarray   = []
    SFchannelarray = []

    try:
        current, dirs, files = sfile.walk(channelPath)
    except Exception, e:
        dixie.log('Error in getAllChannels - Master List: %s' % str(e))
        return channelarray

    for file in files:
        channelarray.append(file)

    if showSFchannels == 'true':
        try:
            current, dirs, files = sfile.walk(SF_CHANNELS)
        except Exception, e:
            dixie.log('Error in getAllChannels - SF List: %s' % str(e))
            return SFchannelarray
    
        for dir in dirs:
            if os.listdir(os.path.join(SF_CHANNELS,dir)):
                if os.path.exists(os.path.join(SF_CHANNELS,dir,'favourites.xml')):
                    SFchannelarray.append(dir)

        nk=set(channelarray).intersection(SFchannelarray)
        for x in channelarray:
            if x in nk:
                channels.append(x)
        dixie.log('SF Folders Found: %s' % str(channels))

    else:
        channels = channelarray
    return channels


def main():          
    if os.path.exists(dbpath):
        con = sqlite.connect(dbpath)
        cur = con.cursor()
        programcount = cur.execute("SELECT COUNT(*) FROM programs;")
        if showSFchannels == 'true':
            channelcount = SF_Folder_Count()
        else:
            channelcount = True
        if (programcount and channelcount):
            windowID = xbmcgui.Window(10000).getProperty('TVP_WINDOW')
            try:
                windowID = int(windowID)
                xbmc.executebuiltin('ActivateWindow(%d)' % windowID)  
                return
            except:
                pass

            name   = dixie.TITLE + ' Launcher'
            script = os.path.join(dixie.HOME, 'launch.py')
            args   = ''
            cmd    = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (name, script, args, 0)

            xbmc.executebuiltin('CancelAlarm(%s,True)' % name)        
            xbmc.executebuiltin(cmd)
        else:
            dialog.ok(ADDON.getLocalizedString(30823),ADDON.getLocalizedString(30824))

    else:
        dialog.ok(ADDON.getLocalizedString(30823),ADDON.getLocalizedString(30824))
